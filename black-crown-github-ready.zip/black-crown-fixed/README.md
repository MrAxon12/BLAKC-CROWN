# BLACK CROWN — sitio web

Proyecto web de BLACK CROWN, preparado para publicarse como sitio estático en GitHub Pages.

## Estructura

- `index.html` — página principal y vistas internas.
- `css/styles.css` — estilos.
- `js/app.js` — navegación, reservaciones y autenticación.
- `js/panel.js` — panel privado.
- `js/firebase-config.js` — configuración de Firebase.
- `js/firebase-init.js` — inicialización de Firebase.
- `js/defaults.js` — servicios y horarios de demostración.
- `js/utils.js` — utilidades.
- `img/` — imágenes.

## Publicar en GitHub Pages

1. Crea un repositorio, por ejemplo `black-crown`.
2. Sube TODO el contenido de esta carpeta a la rama `main`.
3. En GitHub abre **Settings → Pages**.
4. En **Build and deployment**, selecciona **Deploy from a branch**.
5. Elige `main` y `/ (root)` y guarda.
6. Espera a que GitHub Pages publique el sitio.

## Firebase

El proyecto funciona en modo demo mientras `js/firebase-config.js` conserve `TU_API_KEY` y `TU_PROYECTO`.

Para activar reservaciones y acceso privado necesitas:

- Firebase Authentication con Email/Password.
- Firestore.
- Cloud Functions que expongan `getAvailability` y `createBooking`.
- Reglas de Firestore y funciones que validen roles (`owner` / `barbero`).

La configuración web de Firebase puede estar en el navegador; no coloques claves privadas ni archivos de Service Account en GitHub.

## Importante antes de producción

Completa los datos reales de negocio, teléfono, correo, dirección, horarios, dominio e imágenes. Revisa el Aviso de Privacidad y los Términos con los datos reales del negocio. No publiques credenciales privadas.
