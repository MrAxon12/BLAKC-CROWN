/**
 * Inicialización de Firebase (SDK modular v10 desde el CDN oficial de Google).
 * Si cambias la versión, cámbiala en TODAS las importaciones de este proyecto.
 */
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { getFunctions } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-functions.js";
import {
  firebaseConfig, FUNCTIONS_REGION, RECAPTCHA_V3_SITE_KEY, isFirebaseConfigured
} from "./firebase-config.js";

let app = null, auth = null, db = null, functions = null;

if (isFirebaseConfigured) {
  app = initializeApp(firebaseConfig);

  // App Check (opcional): solo se carga si pusiste una site key.
  if (RECAPTCHA_V3_SITE_KEY) {
    const { initializeAppCheck, ReCaptchaV3Provider } =
      await import("https://www.gstatic.com/firebasejs/10.14.1/firebase-app-check.js");
    initializeAppCheck(app, {
      provider: new ReCaptchaV3Provider(RECAPTCHA_V3_SITE_KEY),
      isTokenAutoRefreshEnabled: true
    });
  }

  auth = getAuth(app);
  db = getFirestore(app);
  functions = getFunctions(app, FUNCTIONS_REGION);
}

export { app, auth, db, functions, isFirebaseConfigured };
