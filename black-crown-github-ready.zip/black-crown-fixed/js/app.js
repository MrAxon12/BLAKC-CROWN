/**
 * BLACK CROWN - Lógica del sitio público, reservaciones y login.
 * El panel privado vive en panel.js.
 */
import { auth, db, functions, isFirebaseConfigured } from "./firebase-init.js";
import { collection, query, where, getDocs, doc, getDoc } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { onAuthStateChanged, signInWithEmailAndPassword, signOut, sendPasswordResetEmail } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { httpsCallable } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-functions.js";
import { $, $$, esc, fmtMoney, fmtDate, todayStr, addDays, friendlyError, toast } from "./utils.js";
import { DEFAULT_SERVICES, DEFAULT_CONFIG, DAY_ORDER, DAY_NAMES } from "./defaults.js";
import { mountPanel, unmountPanel } from "./panel.js";

document.documentElement.classList.add("js");
$("#year").textContent = new Date().getFullYear();

/* ======================================================================
   1. NAVEGACIÓN ENTRE VISTAS (hash: #/privacidad, #/terminos, #/acceso, #/panel...)
   ====================================================================== */
const VIEWS = ["landing", "privacidad", "terminos", "reservaciones", "acceso", "panel"];
const TITLES = {
  landing: "BLACK CROWN | Barbería premium – Cortes, fade y barba con cita en línea",
  privacidad: "Aviso de Privacidad | BLACK CROWN", terminos: "Términos y condiciones | BLACK CROWN",
  reservaciones: "Política de Reservaciones | BLACK CROWN", acceso: "Acceso privado | BLACK CROWN", panel: "Panel | BLACK CROWN"
};
const session = { ready: !isFirebaseConfigured, user: null, profile: null, error: "" };
let currentView = null;
const header = $("#site-header");

function viewFromHash() {
  const h = location.hash;
  if (!h.startsWith("#/")) return "landing";
  const v = h.slice(2).split("?")[0];
  return VIEWS.includes(v) ? v : "landing";
}

function updateHeader() { header.classList.toggle("is-solid", window.scrollY > 40 || currentView !== "landing"); }

function route() {
  const view = viewFromHash();
  // Guardas de navegación (la seguridad REAL está en Firestore Rules; esto es solo experiencia de usuario).
  if (view === "panel" && (!isFirebaseConfigured || (session.ready && !session.profile))) { location.hash = "#/acceso"; return; }
  if (view === "acceso" && session.profile) { location.hash = "#/panel"; return; }

  VIEWS.forEach((v) => { $(`[data-view="${v}"]`).hidden = v !== view; });
  document.body.classList.toggle("in-panel", view === "panel");
  document.title = TITLES[view];
  const previous = currentView;
  currentView = view;
  updateHeader();
  closeNav();

  if (view === "panel") { if (session.ready) mountPanel(session, { logout }); }
  else unmountPanel();

  if (view === "landing") {
    const id = location.hash.slice(1);
    const target = id && !id.startsWith("/") ? document.getElementById(id) : null;
    if (target) target.scrollIntoView(); else if (previous !== "landing") window.scrollTo(0, 0);
  } else window.scrollTo(0, 0);

  if (view === "acceso" && session.error) { showAlert($("#login-alert"), session.error); session.error = ""; }
}
window.addEventListener("hashchange", route);
window.addEventListener("scroll", updateHeader, { passive: true });

/* Menú hamburguesa */
const nav = $("#nav"), navToggle = $("#nav-toggle");
function closeNav() { nav.classList.remove("is-open"); navToggle.setAttribute("aria-expanded", "false"); navToggle.setAttribute("aria-label", "Abrir menú"); }
navToggle.addEventListener("click", () => {
  const open = nav.classList.toggle("is-open");
  navToggle.setAttribute("aria-expanded", String(open));
  navToggle.setAttribute("aria-label", open ? "Cerrar menú" : "Abrir menú");
});
document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeNav(); });
$$("#nav a").forEach((a) => a.addEventListener("click", closeNav));

/* Animaciones al hacer scroll (sutiles; respetan prefers-reduced-motion vía CSS) */
const revealObserver = "IntersectionObserver" in window
  ? new IntersectionObserver((entries) => entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("is-in"); revealObserver.unobserve(e.target); } }), { threshold: 0.12 })
  : null;
$$(".reveal").forEach((el) => (revealObserver ? revealObserver.observe(el) : el.classList.add("is-in")));

function showAlert(el, message, ok = false) {
  el.textContent = message; el.hidden = false; el.classList.toggle("form-alert--ok", ok);
}
const hideAlert = (el) => { el.hidden = true; el.textContent = ""; };

/* ======================================================================
   2. DATOS PÚBLICOS (servicios, barberos, horarios) desde Firestore
   ====================================================================== */
const site = { services: [], workers: [], config: null };

async function loadPublicData() {
  if (!isFirebaseConfigured) {
    site.services = DEFAULT_SERVICES.map((s, i) => ({ id: `demo-${i}`, ...s }));
    site.workers = [{ id: "demo", nombre: "Barbero de ejemplo" }];
    site.config = DEFAULT_CONFIG;
    $("#demo-note").hidden = false;
    return;
  }
  try {
    const [servicesSnap, workersSnap, configSnap] = await Promise.all([
      getDocs(query(collection(db, "servicios"), where("active", "==", true))),
      getDocs(query(collection(db, "barberos"), where("activo", "==", true))),
      getDoc(doc(db, "configuracion", "general"))
    ]);
    site.services = servicesSnap.docs.map((d) => ({ id: d.id, ...d.data() }))
      .sort((a, b) => (a.order ?? 999) - (b.order ?? 999) || a.name.localeCompare(b.name));
    site.workers = workersSnap.docs.map((d) => ({ id: d.id, ...d.data() })).sort((a, b) => a.nombre.localeCompare(b.nombre));
    site.config = configSnap.exists() ? configSnap.data() : null;
  } catch (err) {
    console.error(err);
    toast("No se pudo cargar la información del servidor. Recarga la página.", "error");
  }
}

function renderServices() {
  const box = $("#services-list");
  if (!site.services.length) { box.innerHTML = '<p class="empty-note">Los servicios se publicarán muy pronto.</p>'; return; }
  box.innerHTML = site.services.map((s) => `
    <article class="price-row">
      <h3>${esc(s.name)}</h3>
      <span class="price">${fmtMoney(s.price)}</span>
      <span class="meta">${esc(s.duration)} min</span>
      <a class="btn btn--sm btn--ghost" href="#reservar" data-service="${esc(s.id)}" aria-label="Reservar ${esc(s.name)}">Reservar</a>
    </article>`).join("");
}

function renderHours() {
  const list = $("#hours-list");
  const cfg = site.config;
  if (!cfg) { list.innerHTML = "<li>Horario por confirmar</li>"; return; }
  list.innerHTML = DAY_ORDER.map((key) => {
    const d = cfg.days?.[key];
    const text = d && d.active ? `${esc(d.open)} – ${esc(d.close)}` : "Cerrado";
    return `<li><span>${DAY_NAMES[key]}</span><span>${text}</span></li>`;
  }).join("");
}

/* ======================================================================
   3. GALERÍA (reemplaza las imágenes por las tuyas en public/img/gallery/)
   ====================================================================== */
// Para usar tus fotos: sube los archivos con estos nombres (o cambia las rutas) y ajusta el texto alternativo.
const GALLERY = [
  { cat: "Cortes", src: "img/placeholder.svg", alt: "Corte masculino clásico terminado" },
  { cat: "Fade", src: "img/placeholder.svg", alt: "Degradado fade con transición limpia" },
  { cat: "Barbas", src: "img/placeholder.svg", alt: "Diseño de barba perfilada" },
  { cat: "Local", src: "img/placeholder.svg", alt: "Interior de la barbería BLACK CROWN" },
  { cat: "Herramientas", src: "img/placeholder.svg", alt: "Tijeras, navaja y máquinas de corte" },
  { cat: "Ambiente", src: "img/placeholder.svg", alt: "Ambiente de la barbería con estética rock" },
  { cat: "Fade", src: "img/placeholder.svg", alt: "Taper fade visto de perfil" },
  { cat: "Cortes", src: "img/placeholder.svg", alt: "Corte para niño terminado" },
  { cat: "Barbas", src: "img/placeholder.svg", alt: "Barba con acabado a navaja" }
];
let galleryFilter = "Todo";

function renderGallery() {
  const cats = ["Todo", ...new Set(GALLERY.map((g) => g.cat))];
  $("#gallery-filters").innerHTML = cats.map((c) => `<button type="button" class="chip" data-cat="${esc(c)}" aria-pressed="${c === galleryFilter}">${esc(c)}</button>`).join("");
  const items = GALLERY.filter((g) => galleryFilter === "Todo" || g.cat === galleryFilter);
  $("#gallery").innerHTML = items.map((g) => `
    <button type="button" class="gallery__item" data-src="${esc(g.src)}" data-alt="${esc(g.alt)}" aria-label="Ampliar: ${esc(g.alt)}">
      <img src="${esc(g.src)}" alt="${esc(g.alt)}" loading="lazy" width="480" height="480">
      <span class="cap">${esc(g.cat)}</span>
    </button>`).join("");
}
$("#gallery-filters").addEventListener("click", (e) => {
  const chip = e.target.closest("[data-cat]"); if (!chip) return;
  galleryFilter = chip.dataset.cat; renderGallery();
});
// Si una imagen no existe todavía, mostramos un marcador para que sepas qué archivo subir.
$("#gallery").addEventListener("error", (e) => {
  if (e.target.tagName !== "IMG") return;
  const btn = e.target.closest(".gallery__item");
  e.target.replaceWith(Object.assign(document.createElement("div"), {
    className: "ph", innerHTML: `<svg aria-hidden="true"><use href="#ico-image"/></svg><span>Foto de demostración pendiente<br>${esc(btn.dataset.src)}</span>`
  }));
  btn.dataset.missing = "1";
}, true);
$("#gallery").addEventListener("click", (e) => {
  const btn = e.target.closest(".gallery__item");
  if (!btn || btn.dataset.missing) return;
  $("#lightbox-body").innerHTML = `<img src="${esc(btn.dataset.src)}" alt="${esc(btn.dataset.alt)}">`;
  $("#lightbox").showModal();
});

/* ======================================================================
   4. RESERVACIONES PÚBLICAS
   ====================================================================== */
const els = {
  form: $("#booking-form"), service: $("#b-service"), worker: $("#b-worker"), date: $("#b-date"), slots: $("#b-slots"),
  name: $("#b-name"), phone: $("#b-phone"), consent: $("#b-consent"), honeypot: $("#b-website"),
  alert: $("#b-alert"), submit: $("#b-submit"), confirm: $("#b-confirm"), confirmData: $("#b-confirm-data")
};
let slotRequestId = 0;

function fillBookingSelects() {
  els.service.innerHTML = '<option value="">Selecciona un servicio</option>' +
    site.services.map((s) => `<option value="${esc(s.id)}">${esc(s.name)} — ${fmtMoney(s.price)} · ${esc(s.duration)} min</option>`).join("");
  els.worker.innerHTML = '<option value="">Selecciona un barbero</option>' +
    site.workers.map((w) => `<option value="${esc(w.id)}">${esc(w.nombre)}</option>`).join("");
  els.date.min = todayStr(); els.date.max = addDays(todayStr(), 60);
  if (!site.workers.length && isFirebaseConfigured) els.worker.innerHTML = '<option value="">Sin barberos disponibles por ahora</option>';
}

const SLOT_MESSAGES = {
  past: "Elige una fecha de hoy en adelante.", "too-far": "Solo puedes reservar hasta con 60 días de anticipación.",
  closed: "La barbería está cerrada ese día. Elige otra fecha.", blocked: "Ese día no hay servicio. Elige otra fecha.",
  full: "No quedan horarios libres ese día con este barbero. Prueba otra fecha u otro barbero."
};

async function refreshSlots() {
  const [serviceId, workerId, date] = [els.service.value, els.worker.value, els.date.value];
  if (!serviceId || !workerId || !date) { els.slots.innerHTML = '<p class="slots-msg">Elige servicio, barbero y fecha para ver horarios.</p>'; return; }
  if (!isFirebaseConfigured) { els.slots.innerHTML = '<p class="slots-msg">Modo demostración: conecta Firebase para ver horarios reales.</p>'; return; }

  const requestId = ++slotRequestId; // evita que una respuesta lenta pise a una más reciente
  els.slots.innerHTML = '<p class="slots-msg">Buscando horarios libres…</p>';
  try {
    const { data } = await httpsCallable(functions, "getAvailability")({ serviceId, workerId, date });
    if (requestId !== slotRequestId) return;
    if (!data.slots.length) { els.slots.innerHTML = `<p class="slots-msg">${esc(SLOT_MESSAGES[data.reason] || "Sin horarios disponibles.")}</p>`; return; }
    els.slots.innerHTML = data.slots.map((t) => `<label class="slot"><input type="radio" name="b-time" value="${esc(t)}"><span>${esc(t)}</span></label>`).join("");
  } catch (err) {
    if (requestId !== slotRequestId) return;
    console.error(err);
    els.slots.innerHTML = `<p class="slots-msg">${esc(friendlyError(err))}</p>`;
  }
}
[els.service, els.worker, els.date].forEach((el) => el.addEventListener("change", () => { hideAlert(els.alert); refreshSlots(); }));

// Botón "Reservar" en cada servicio: preselecciona el servicio.
$("#services-list").addEventListener("click", (e) => {
  const btn = e.target.closest("[data-service]"); if (!btn) return;
  els.service.value = btn.dataset.service; refreshSlots();
});

function validateBooking() {
  if (!els.service.value) return "Selecciona un servicio.";
  if (!els.worker.value) return "Selecciona un barbero.";
  if (!els.date.value) return "Selecciona una fecha.";
  if (els.date.value < todayStr()) return "La fecha no puede ser pasada.";
  if (!els.form.querySelector('input[name="b-time"]:checked')) return "Selecciona una hora disponible.";
  if (!/^[\p{L}\p{M}'’.\- ]{2,60}$/u.test(els.name.value.trim())) return "Escribe tu nombre (2 a 60 letras, sin números ni símbolos).";
  if (!/^\d{10}$/.test(els.phone.value.replace(/\D/g, "").replace(/^521?(?=\d{10}$)/, ""))) return "Escribe un teléfono válido de 10 dígitos.";
  if (!els.consent.checked) return "Debes aceptar el Aviso de Privacidad para reservar.";
  return "";
}

els.form.addEventListener("submit", async (e) => {
  e.preventDefault();
  hideAlert(els.alert);
  if (!isFirebaseConfigured) { showAlert(els.alert, "Las reservaciones están desactivadas hasta conectar Firebase (ver README)."); return; }
  const problem = validateBooking();
  if (problem) { showAlert(els.alert, problem); return; }

  els.submit.disabled = true; els.submit.textContent = "Registrando tu cita…";
  try {
    const { data } = await httpsCallable(functions, "createBooking")({
      serviceId: els.service.value, workerId: els.worker.value, date: els.date.value,
      time: els.form.querySelector('input[name="b-time"]:checked').value,
      name: els.name.value, phone: els.phone.value, consent: els.consent.checked,
      website: els.honeypot.value
    });
    showConfirmation(data);
  } catch (err) {
    console.error(err);
    showAlert(els.alert, friendlyError(err));
    if (String(err.code).endsWith("already-exists")) refreshSlots();
  } finally {
    els.submit.disabled = false; els.submit.textContent = "Confirmar cita";
  }
});

function showConfirmation(d) {
  els.confirmData.innerHTML = `
    <dt>Servicio</dt><dd>${esc(d.service)}</dd>
    <dt>Barbero</dt><dd>${esc(d.worker)}</dd>
    <dt>Fecha</dt><dd>${esc(fmtDate(d.date))}</dd>
    <dt>Hora</dt><dd>${esc(d.time)}</dd>
    <dt>Duración</dt><dd>${esc(d.duration)} min</dd>
    <dt>Folio</dt><dd>${esc(d.folio)}</dd>`;
  els.form.hidden = true; els.confirm.hidden = false; els.confirm.focus();
}
$("#b-again").addEventListener("click", () => {
  els.form.reset(); els.confirm.hidden = true; els.form.hidden = false; refreshSlots();
});

/* ======================================================================
   5. LOGIN PRIVADO (Firebase Authentication)
   El rol se determina por la cuenta autenticada (usuarios/{uid}), NUNCA por lo que el usuario elija.
   ====================================================================== */
const loginForm = $("#login-form"), loginAlert = $("#login-alert");

loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  hideAlert(loginAlert); session.error = "";
  if (!isFirebaseConfigured) { showAlert(loginAlert, "Firebase aún no está configurado (ver README)."); return; }
  const email = $("#login-user").value.trim(), password = $("#login-pass").value;
  if (!email || !password) { showAlert(loginAlert, "Escribe tu usuario y contraseña."); return; }
  const btn = $("#login-submit"); btn.disabled = true; btn.textContent = "Entrando…";
  try {
    await signInWithEmailAndPassword(auth, email, password);
    $("#login-pass").value = "";
    // onAuthStateChanged se encarga de cargar el rol y abrir el panel.
  } catch (err) {
    const c = String(err.code);
    const msg = c.includes("too-many-requests") ? "Demasiados intentos. Espera unos minutos e inténtalo de nuevo."
      : c.includes("user-disabled") ? "Esta cuenta está desactivada. Contacta al propietario."
      : c.includes("network") ? "Sin conexión. Revisa tu internet."
      : "Usuario o contraseña incorrectos.";
    showAlert(loginAlert, msg);
  } finally { btn.disabled = false; btn.textContent = "Entrar"; }
});

$("#forgot-btn").addEventListener("click", async () => {
  const email = $("#login-user").value.trim();
  if (!isFirebaseConfigured) return;
  if (!email) { showAlert(loginAlert, "Escribe tu usuario (correo) y vuelve a pulsar “¿Olvidaste tu contraseña?”."); return; }
  try { await sendPasswordResetEmail(auth, email); } catch (err) { console.warn(err.code); }
  // Mensaje genérico a propósito: no revelamos si la cuenta existe.
  showAlert(loginAlert, "Si la cuenta existe, recibirás un correo para restablecer tu contraseña.", true);
});

async function fetchProfile(uid) {
  const snap = await getDoc(doc(db, "usuarios", uid));
  return snap.exists() ? { uid, ...snap.data() } : null;
}

async function logout() {
  await signOut(auth);
  location.hash = "#/";
}

if (isFirebaseConfigured) {
  onAuthStateChanged(auth, async (user) => {
    session.user = user; session.profile = null;
    if (user) {
      try {
        const profile = await fetchProfile(user.uid);
        if (profile && profile.activo === true && ["owner", "barbero"].includes(profile.rol)) session.profile = profile;
        else {
          session.error = "Tu cuenta no está autorizada para entrar al panel. Contacta al propietario.";
          await signOut(auth);
        }
      } catch (err) {
        console.error(err);
        session.error = "No se pudo verificar tu cuenta. Inténtalo de nuevo.";
        await signOut(auth);
      }
    }
    session.ready = true;
    route();
  });
}

/* ======================================================================
   6. ARRANQUE
   ====================================================================== */
(async function init() {
  route();
  await loadPublicData();
  renderServices(); renderHours(); renderGallery(); fillBookingSelects();
  $$(".reveal").forEach((el) => revealObserver?.observe(el));
  if (location.hash && !location.hash.startsWith("#/")) route(); // reposiciona en el ancla después de cargar contenido
})();
