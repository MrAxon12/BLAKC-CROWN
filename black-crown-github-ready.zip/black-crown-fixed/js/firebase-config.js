/**
 * ============================================================================
 *  >>> AQUÍ PEGAS TUS CREDENCIALES DE FIREBASE <<<
 * ============================================================================
 * Dónde obtenerlas: Consola de Firebase > Configuración del proyecto (⚙) >
 * General > "Tus apps" > App web (</>) > "Configuración del SDK" > Config.
 *
 * ¿Es seguro que estén en el navegador? Sí: la apiKey web de Firebase NO es un
 * secreto; identifica tu proyecto. La seguridad real está en firestore.rules,
 * en las Cloud Functions y (opcional) en App Check.
 * NUNCA pegues aquí una llave privada ni un Service Account JSON.
 */
export const firebaseConfig = {
  apiKey: "TU_API_KEY",
  authDomain: "TU_PROYECTO.firebaseapp.com",
  projectId: "TU_PROYECTO",
  storageBucket: "TU_PROYECTO.firebasestorage.app",
  messagingSenderId: "XXXXXXXX",
  appId: "XXXXXXXX"
};

/** Región donde se despliegan las Cloud Functions (debe coincidir con functions/index.js). */
export const FUNCTIONS_REGION = "us-central1";

/** Zona horaria del negocio (debe coincidir con TIMEZONE en functions/.env). */
export const BUSINESS_TIMEZONE = "America/Mexico_City";

/**
 * OPCIONAL - App Check con reCAPTCHA v3 (protección anti-bots, ver README).
 * Déjalo vacío ("") para no cargar ningún servicio de Google reCAPTCHA.
 * Si lo usas, debes mencionarlo en el Aviso de Privacidad (ya hay un párrafo preparado).
 */
export const RECAPTCHA_V3_SITE_KEY = "";

/** true cuando ya pegaste credenciales reales. Si es false, el sitio corre en "modo demo". */
export const isFirebaseConfigured =
  !!firebaseConfig.apiKey && !firebaseConfig.apiKey.startsWith("TU_") && !firebaseConfig.projectId.startsWith("TU_");
