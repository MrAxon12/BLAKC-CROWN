/** Utilidades compartidas: DOM seguro, formato de fechas/dinero y avisos (toasts). */
import { BUSINESS_TIMEZONE } from "./firebase-config.js";

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/** Escapa texto antes de insertarlo en innerHTML (evita inyección de HTML/JS). */
export function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

const money = new Intl.NumberFormat("es-MX", { style: "currency", currency: "MXN", maximumFractionDigits: 0 });
export const fmtMoney = (n) => money.format(Number(n) || 0);

/** Fecha de hoy (YYYY-MM-DD) en la zona horaria del negocio. */
export function todayStr() {
  const p = new Intl.DateTimeFormat("en-CA", { timeZone: BUSINESS_TIMEZONE, year: "numeric", month: "2-digit", day: "2-digit" }).format(new Date());
  return p; // en-CA produce YYYY-MM-DD
}

export function addDays(dateStr, n) {
  const [y, m, d] = dateStr.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + n));
  return dt.toISOString().slice(0, 10);
}

/** "2026-10-05" -> "lun 5 oct 2026" (sin desfases por zona horaria). */
export function fmtDate(dateStr) {
  if (!dateStr) return "";
  const [y, m, d] = dateStr.split("-").map(Number);
  return new Intl.DateTimeFormat("es-MX", { timeZone: "UTC", weekday: "short", day: "numeric", month: "short", year: "numeric" })
    .format(new Date(Date.UTC(y, m - 1, d)));
}

export const timeToMin = (t) => { const [h, m] = String(t).split(":").map(Number); return h * 60 + m; };
export const minToTime = (n) => `${String(Math.floor(n / 60)).padStart(2, "0")}:${String(n % 60).padStart(2, "0")}`;
export const endTime = (time, duration) => minToTime(timeToMin(time) + Number(duration || 0));

/** Aviso flotante accesible (role=status). */
export function toast(message, type = "info") {
  let zone = $("#toast-zone");
  if (!zone) {
    zone = document.createElement("div");
    zone.id = "toast-zone"; zone.className = "toast-zone";
    zone.setAttribute("role", "status"); zone.setAttribute("aria-live", "polite");
    document.body.appendChild(zone);
  }
  const t = document.createElement("div");
  t.className = `toast toast--${type}`;
  t.textContent = message;
  zone.appendChild(t);
  setTimeout(() => t.remove(), 5000);
}

/** Traduce errores de Firebase / Cloud Functions a mensajes comprensibles. */
export function friendlyError(err) {
  const code = String(err?.code || "");
  // Errores "esperados" enviados por nuestras funciones (HttpsError) traen mensaje en español.
  const expected = code.startsWith("functions/") && ["invalid-argument", "failed-precondition", "already-exists",
    "resource-exhausted", "permission-denied", "not-found", "unauthenticated"].some((c) => code.endsWith(c));
  if (expected && err.message) return err.message;
  if (code.includes("unavailable") || code.includes("network")) return "Sin conexión con el servidor. Revisa tu internet e inténtalo de nuevo.";
  if (code.includes("permission-denied")) return "No tienes permiso para realizar esta acción.";
  return "Ocurrió un error inesperado. Inténtalo de nuevo en unos minutos.";
}

/** Descarga un archivo de texto generado en el navegador. */
export function downloadText(filename, text, mime = "application/json") {
  const url = URL.createObjectURL(new Blob([text], { type: mime }));
  const a = Object.assign(document.createElement("a"), { href: url, download: filename });
  document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(url);
}
