/**
 * Panel privado de BLACK CROWN.
 * Esta versión no expone datos sensibles en el frontend y usa la sesión
 * autenticada que valida app.js. Las operaciones administrativas pueden
 * añadirse después mediante Cloud Functions/Firestore Rules.
 */
import { $, esc, toast } from "./utils.js";

let mounted = false;
let cleanup = [];

function on(el, event, handler) {
  el?.addEventListener(event, handler);
  if (el) cleanup.push(() => el.removeEventListener(event, handler));
}

function roleLabel(role) {
  return role === "owner" ? "Propietario" : "Barbero";
}

function render(session, actions) {
  const nav = $("#side-nav");
  const user = $("#side-user");
  const main = $("#panel-main");
  if (!nav || !user || !main) return;

  const profile = session.profile || {};
  const name = profile.nombre || profile.name || profile.email || "Usuario";
  const role = roleLabel(profile.rol);

  nav.innerHTML = `
    <a class="side-link is-active" href="#/panel">Resumen</a>
    <a class="side-link" href="#reservar">Ver sitio</a>
  `;

  user.innerHTML = `
    <strong>${esc(name)}</strong>
    <small>${esc(role)}</small>
    <button class="link-btn" id="panel-logout" type="button">Cerrar sesión</button>
  `;

  main.innerHTML = `
    <section class="panel-section">
      <div class="panel-heading">
        <div>
          <p class="eyebrow">Área privada</p>
          <h1>Bienvenido, ${esc(name)}</h1>
          <p class="muted">Sesión iniciada como ${esc(role)}.</p>
        </div>
        <a class="btn btn--sm" href="#inicio">Ver página pública</a>
      </div>

      <div class="panel-cards">
        <article class="panel-card">
          <span class="panel-card__label">Cuenta</span>
          <strong>${esc(profile.email || session.user?.email || "—")}</strong>
          <small>Autenticación mediante Firebase</small>
        </article>
        <article class="panel-card">
          <span class="panel-card__label">Rol</span>
          <strong>${esc(role)}</strong>
          <small>Asignado por el perfil del usuario</small>
        </article>
        <article class="panel-card">
          <span class="panel-card__label">Estado</span>
          <strong>Activo</strong>
          <small>Acceso autorizado</small>
        </article>
      </div>

      <div class="panel-notice">
        <h2>Panel conectado</h2>
        <p>La interfaz privada está lista. Las operaciones de citas, servicios, barberos y configuración deben ejecutarse con Firestore Rules y Cloud Functions para mantener la seguridad.</p>
      </div>
    </section>
  `;

  on($("#panel-logout"), "click", async () => {
    try {
      await actions.logout();
    } catch (error) {
      console.error(error);
      toast("No se pudo cerrar la sesión. Inténtalo de nuevo.", "error");
    }
  });
}

export function mountPanel(session, actions) {
  if (mounted) return;
  mounted = true;
  render(session, actions);

  const toggle = $("#side-toggle");
  const sidebar = $("#sidebar");
  on(toggle, "click", () => {
    const open = sidebar.classList.toggle("is-open");
    toggle.setAttribute("aria-expanded", String(open));
  });
}

export function unmountPanel() {
  cleanup.forEach((fn) => fn());
  cleanup = [];
  mounted = false;
}
