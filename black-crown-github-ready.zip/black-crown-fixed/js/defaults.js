/**
 * Datos iniciales (los de tu solicitud). Se usan para:
 *  - Mostrar el sitio en "modo demo" mientras no conectes Firebase.
 *  - El botón "Cargar servicios / horario iniciales" del panel del propietario.
 * Después de cargarlos, TODO se administra desde el panel (Firestore).
 */
export const DEFAULT_SERVICES = [
  { name: "Corte Masculino", price: 180, duration: 45, active: true, order: 1 },
  { name: "Corte para Niño", price: 150, duration: 45, active: true, order: 2 },
  { name: "Fade / Degradado", price: 220, duration: 60, active: true, order: 3 },
  { name: "Taper Fade", price: 220, duration: 60, active: true, order: 4 },
  { name: "Diseño de Barba", price: 150, duration: 30, active: true, order: 5 },
  { name: "Facial", price: 180, duration: 45, active: true, order: 6 },
  { name: "Exfoliación", price: 150, duration: 30, active: true, order: 7 },
  { name: "Combo Premium", price: 350, duration: 90, active: true, order: 8 },
  { name: "Mullet", price: 220, duration: 60, active: true, order: 9 },
  { name: "Diseño Especial", price: 280, duration: 75, active: true, order: 10 }
];

/** Claves de día = Date.getDay(): 0 domingo ... 6 sábado. */
export const DAY_KEYS = ["dom", "lun", "mar", "mie", "jue", "vie", "sab"];
export const DAY_NAMES = { lun: "Lunes", mar: "Martes", mie: "Miércoles", jue: "Jueves", vie: "Viernes", sab: "Sábado", dom: "Domingo" };
export const DAY_ORDER = ["lun", "mar", "mie", "jue", "vie", "sab", "dom"];

export const DEFAULT_CONFIG = {
  days: {
    lun: { active: true, open: "09:00", close: "18:00" },
    mar: { active: true, open: "09:00", close: "18:00" },
    mie: { active: true, open: "09:00", close: "18:00" },
    jue: { active: true, open: "09:00", close: "18:00" },
    vie: { active: true, open: "09:00", close: "18:00" },
    sab: { active: true, open: "09:00", close: "14:00" },
    dom: { active: false, open: "09:00", close: "14:00" }
  },
  blockedDates: []
};
